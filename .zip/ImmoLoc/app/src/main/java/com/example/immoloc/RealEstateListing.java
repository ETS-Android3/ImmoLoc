package com.example.immoloc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RealEstateListing extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_real_estate_listing);
    }

    /** Ici apparaîtront les annonces les plus récentes, fetchées depuis la base de données **/

    /** Fragment pour la toolbar du bas à faire et qui sera commune à d'autres écrans **/
}