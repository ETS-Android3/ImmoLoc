package com.example.immoloc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegistrationType extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_type);
    }
}