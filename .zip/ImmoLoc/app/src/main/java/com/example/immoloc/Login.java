package com.example.immoloc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Login extends AppCompatActivity {

    TextView mdpOublié, inscription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        /*
        Logique à définir, connexion à une base de données
         */

        // Mot de passe oublié ?
        mdpOublié = findViewById(R.id.alreadyHaveAccount);
        mdpOublié.setOnClickListener(view -> {
            // Définir un formulaire d'oubli d'identifiants et y envoyer l'utilisateur
        });

        // Redirection sur la page d'inscription
        inscription = findViewById(R.id.signupBtn);
        inscription.setOnClickListener(view -> {
            Intent redirection = new Intent(this, Signup.class);
            startActivity(redirection);
        });
    }
}