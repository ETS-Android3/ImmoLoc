package com.example.immoloc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Signup extends AppCompatActivity {

    TextView alreadyHaveAcc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Redirection sur la page de Connexion si utilisateur déjà détenteur d'un compte
        alreadyHaveAcc = findViewById(R.id.alreadyHaveAccount);
        alreadyHaveAcc.setOnClickListener(view -> {
            Intent redirection = new Intent(this, Login.class);
            startActivity(redirection);
        });
    }


}