Development of a a real estate rental mobile app that runs on Android platforms.
